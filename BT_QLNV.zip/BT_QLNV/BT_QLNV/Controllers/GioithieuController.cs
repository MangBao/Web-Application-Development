﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BT_QLNV.Controllers
{
    public class GioithieuController : Controller
    {
        // GET: Gioithieu
        public ActionResult Gioithieu()
        {
            return View();
        }
    }
}